/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package cat.copernic.CarConnect.Entity.MySQL.Enums;

/**
 *
 * @author david
 */
public enum TipusLlicenciaConduccio {
    A1,
    A,
    B,
    C1,
    C,
    D1,
    D,
    BE,
    C1E,
    CE,
    D1E,
    DE

}
